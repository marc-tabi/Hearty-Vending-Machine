﻿namespace Hearty_Application
{
    partial class frmHearty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHearty));
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nud20 = new System.Windows.Forms.NumericUpDown();
            this.GroupBoxRunningCredit = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.Label33 = new System.Windows.Forms.Label();
            this.LabelCredit = new System.Windows.Forms.Label();
            this.btnFinalNext = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nud19 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.nud18 = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.nud17 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.nud16 = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.nud15 = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.nud14 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.nud13 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.nud12 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.nud11 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nud30 = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.nud29 = new System.Windows.Forms.NumericUpDown();
            this.nud21 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.nud28 = new System.Windows.Forms.NumericUpDown();
            this.nud22 = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.nud27 = new System.Windows.Forms.NumericUpDown();
            this.nud23 = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.nud26 = new System.Windows.Forms.NumericUpDown();
            this.nud24 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.nud25 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.nud1 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.nud2 = new System.Windows.Forms.NumericUpDown();
            this.nud3 = new System.Windows.Forms.NumericUpDown();
            this.nud4 = new System.Windows.Forms.NumericUpDown();
            this.nud5 = new System.Windows.Forms.NumericUpDown();
            this.nud6 = new System.Windows.Forms.NumericUpDown();
            this.nud7 = new System.Windows.Forms.NumericUpDown();
            this.nud8 = new System.Windows.Forms.NumericUpDown();
            this.nud9 = new System.Windows.Forms.NumericUpDown();
            this.nud10 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GroupBoxEnterCredit = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.Label34 = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.textboxBill = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureArrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud20)).BeginInit();
            this.GroupBoxRunningCredit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud10)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.GroupBoxEnterCredit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sitka Small", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1391, 1164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total price";
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.BackColor = System.Drawing.SystemColors.WindowText;
            this.txtTotalPrice.Font = new System.Drawing.Font("Myriad Pro", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalPrice.ForeColor = System.Drawing.Color.Red;
            this.txtTotalPrice.Location = new System.Drawing.Point(1500, 1168);
            this.txtTotalPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.Size = new System.Drawing.Size(87, 36);
            this.txtTotalPrice.TabIndex = 10;
            this.txtTotalPrice.Text = "0.00";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(16, 430);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(404, 340);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox2.Controls.Add(this.nud20);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nud19);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.nud18);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.nud17);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.nud16);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.nud15);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.nud14);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.nud13);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.nud12);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.nud11);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(485, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(451, 433);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hearty Beverages @ 1.00 AED Each";
            // 
            // nud20
            // 
            this.nud20.ForeColor = System.Drawing.Color.Maroon;
            this.nud20.Location = new System.Drawing.Point(17, 382);
            this.nud20.Margin = new System.Windows.Forms.Padding(4);
            this.nud20.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud20.Name = "nud20";
            this.nud20.Size = new System.Drawing.Size(56, 27);
            this.nud20.TabIndex = 80;
            this.nud20.ValueChanged += new System.EventHandler(this.nud20_ValueChanged);
            // 
            // GroupBoxRunningCredit
            // 
            this.GroupBoxRunningCredit.BackColor = System.Drawing.Color.White;
            this.GroupBoxRunningCredit.Controls.Add(this.btnCancel);
            this.GroupBoxRunningCredit.Controls.Add(this.Label33);
            this.GroupBoxRunningCredit.Controls.Add(this.LabelCredit);
            this.GroupBoxRunningCredit.Controls.Add(this.btnFinalNext);
            this.GroupBoxRunningCredit.Controls.Add(this.label35);
            this.GroupBoxRunningCredit.Location = new System.Drawing.Point(0, 0);
            this.GroupBoxRunningCredit.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBoxRunningCredit.Name = "GroupBoxRunningCredit";
            this.GroupBoxRunningCredit.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBoxRunningCredit.Size = new System.Drawing.Size(956, 272);
            this.GroupBoxRunningCredit.TabIndex = 46;
            this.GroupBoxRunningCredit.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Bell Gothic Std Light", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(704, 119);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(192, 95);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel X";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Label33
            // 
            this.Label33.BackColor = System.Drawing.Color.Black;
            this.Label33.Font = new System.Drawing.Font("Bell Gothic Std Light", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label33.ForeColor = System.Drawing.Color.White;
            this.Label33.Location = new System.Drawing.Point(321, 119);
            this.Label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(176, 95);
            this.Label33.TabIndex = 6;
            this.Label33.Text = "AED";
            this.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabelCredit
            // 
            this.LabelCredit.BackColor = System.Drawing.Color.Black;
            this.LabelCredit.Font = new System.Drawing.Font("Bell Gothic Std Light", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCredit.ForeColor = System.Drawing.Color.Snow;
            this.LabelCredit.Location = new System.Drawing.Point(52, 119);
            this.LabelCredit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LabelCredit.Name = "LabelCredit";
            this.LabelCredit.Size = new System.Drawing.Size(272, 95);
            this.LabelCredit.TabIndex = 4;
            this.LabelCredit.Text = "0";
            this.LabelCredit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnFinalNext
            // 
            this.btnFinalNext.BackColor = System.Drawing.Color.IndianRed;
            this.btnFinalNext.Font = new System.Drawing.Font("Bell Gothic Std Light", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalNext.Location = new System.Drawing.Point(505, 119);
            this.btnFinalNext.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinalNext.Name = "btnFinalNext";
            this.btnFinalNext.Size = new System.Drawing.Size(192, 95);
            this.btnFinalNext.TabIndex = 2;
            this.btnFinalNext.Text = "&Next >";
            this.btnFinalNext.UseVisualStyleBackColor = false;
            this.btnFinalNext.Click += new System.EventHandler(this.btnFinalNext_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(42, 54);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(474, 51);
            this.label35.TabIndex = 0;
            this.label35.Text = "Remaining Credits ❤";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(81, 353);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(344, 20);
            this.label6.TabIndex = 80;
            this.label6.Text = "19 Poland Springs (Lemon Sparkling Water)";
            // 
            // nud19
            // 
            this.nud19.ForeColor = System.Drawing.Color.Maroon;
            this.nud19.Location = new System.Drawing.Point(17, 343);
            this.nud19.Margin = new System.Windows.Forms.Padding(4);
            this.nud19.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud19.Name = "nud19";
            this.nud19.Size = new System.Drawing.Size(56, 27);
            this.nud19.TabIndex = 79;
            this.nud19.ValueChanged += new System.EventHandler(this.nud19_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(81, 47);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(322, 20);
            this.label14.TabIndex = 71;
            this.label14.Text = "11 Long Snows Vitamin Soda (Pure Cola)";
            // 
            // nud18
            // 
            this.nud18.ForeColor = System.Drawing.Color.Maroon;
            this.nud18.Location = new System.Drawing.Point(17, 305);
            this.nud18.Margin = new System.Windows.Forms.Padding(4);
            this.nud18.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud18.Name = "nud18";
            this.nud18.Size = new System.Drawing.Size(56, 27);
            this.nud18.TabIndex = 78;
            this.nud18.ValueChanged += new System.EventHandler(this.nud18_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(81, 277);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(249, 20);
            this.label20.TabIndex = 77;
            this.label20.Text = "17 Embodi (Citrus Resurgence)";
            // 
            // nud17
            // 
            this.nud17.ForeColor = System.Drawing.Color.Maroon;
            this.nud17.Location = new System.Drawing.Point(17, 267);
            this.nud17.Margin = new System.Windows.Forms.Padding(4);
            this.nud17.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud17.Name = "nud17";
            this.nud17.Size = new System.Drawing.Size(56, 27);
            this.nud17.TabIndex = 77;
            this.nud17.ValueChanged += new System.EventHandler(this.nud17_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(81, 390);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(246, 20);
            this.label7.TabIndex = 79;
            this.label7.Text = "20 AQUAFINA (Mineral Water)";
            // 
            // nud16
            // 
            this.nud16.ForeColor = System.Drawing.Color.Maroon;
            this.nud16.Location = new System.Drawing.Point(17, 229);
            this.nud16.Margin = new System.Windows.Forms.Padding(4);
            this.nud16.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud16.Name = "nud16";
            this.nud16.Size = new System.Drawing.Size(56, 27);
            this.nud16.TabIndex = 76;
            this.nud16.ValueChanged += new System.EventHandler(this.nud16_ValueChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(81, 318);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(295, 20);
            this.label21.TabIndex = 78;
            this.label21.Text = "18 Balanced (Vanilla Nutrition Drink)";
            // 
            // nud15
            // 
            this.nud15.ForeColor = System.Drawing.Color.Maroon;
            this.nud15.Location = new System.Drawing.Point(17, 191);
            this.nud15.Margin = new System.Windows.Forms.Padding(4);
            this.nud15.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud15.Name = "nud15";
            this.nud15.Size = new System.Drawing.Size(56, 27);
            this.nud15.TabIndex = 75;
            this.nud15.ValueChanged += new System.EventHandler(this.nud15_ValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(81, 241);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(196, 20);
            this.label19.TabIndex = 76;
            this.label19.Text = "16 Steaz (Berry Energy)";
            // 
            // nud14
            // 
            this.nud14.ForeColor = System.Drawing.Color.Maroon;
            this.nud14.Location = new System.Drawing.Point(17, 153);
            this.nud14.Margin = new System.Windows.Forms.Padding(4);
            this.nud14.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud14.Name = "nud14";
            this.nud14.Size = new System.Drawing.Size(56, 27);
            this.nud14.TabIndex = 74;
            this.nud14.ValueChanged += new System.EventHandler(this.nud14_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(81, 201);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(210, 20);
            this.label18.TabIndex = 75;
            this.label18.Text = "15 Blue Sky (Blue Energy)";
            // 
            // nud13
            // 
            this.nud13.ForeColor = System.Drawing.Color.Maroon;
            this.nud13.Location = new System.Drawing.Point(17, 114);
            this.nud13.Margin = new System.Windows.Forms.Padding(4);
            this.nud13.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud13.Name = "nud13";
            this.nud13.Size = new System.Drawing.Size(56, 27);
            this.nud13.TabIndex = 73;
            this.nud13.ValueChanged += new System.EventHandler(this.nud13_ValueChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(81, 86);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(163, 20);
            this.label15.TabIndex = 72;
            this.label15.Text = "12 Zevia (Diet Cola)";
            // 
            // nud12
            // 
            this.nud12.ForeColor = System.Drawing.Color.Maroon;
            this.nud12.Location = new System.Drawing.Point(17, 76);
            this.nud12.Margin = new System.Windows.Forms.Padding(4);
            this.nud12.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud12.Name = "nud12";
            this.nud12.Size = new System.Drawing.Size(56, 27);
            this.nud12.TabIndex = 72;
            this.nud12.ValueChanged += new System.EventHandler(this.nud12_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(81, 162);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(238, 20);
            this.label17.TabIndex = 74;
            this.label17.Text = "14 WAT-AHH! (Energy Water)";
            // 
            // nud11
            // 
            this.nud11.ForeColor = System.Drawing.Color.Maroon;
            this.nud11.Location = new System.Drawing.Point(17, 38);
            this.nud11.Margin = new System.Windows.Forms.Padding(4);
            this.nud11.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud11.Name = "nud11";
            this.nud11.Size = new System.Drawing.Size(56, 27);
            this.nud11.TabIndex = 71;
            this.nud11.ValueChanged += new System.EventHandler(this.nud11_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(81, 126);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(303, 20);
            this.label16.TabIndex = 73;
            this.label16.Text = "13 The Switch (Sparkling Grape Juice)";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox3.Controls.Add(this.nud30);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.nud29);
            this.groupBox3.Controls.Add(this.nud21);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.nud28);
            this.groupBox3.Controls.Add(this.nud22);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.nud27);
            this.groupBox3.Controls.Add(this.nud23);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.nud26);
            this.groupBox3.Controls.Add(this.nud24);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.nud25);
            this.groupBox3.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(956, 16);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(485, 432);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Hearty Luncheons @ 4.00 AED Each";
            // 
            // nud30
            // 
            this.nud30.BackColor = System.Drawing.Color.White;
            this.nud30.ForeColor = System.Drawing.Color.Maroon;
            this.nud30.Location = new System.Drawing.Point(19, 382);
            this.nud30.Margin = new System.Windows.Forms.Padding(4);
            this.nud30.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud30.Name = "nud30";
            this.nud30.Size = new System.Drawing.Size(56, 27);
            this.nud30.TabIndex = 99;
            this.nud30.ValueChanged += new System.EventHandler(this.nud30_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(83, 47);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(266, 20);
            this.label23.TabIndex = 82;
            this.label23.Text = "21 Koyo (Asian Vegetable Ramen)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(83, 353);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(352, 20);
            this.label22.TabIndex = 100;
            this.label22.Text = "29 Simply Asia (Spring Vegetable Soup Bowl)";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(83, 126);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(268, 20);
            this.label31.TabIndex = 86;
            this.label31.Text = "23 St. Dalfour (Pasta & Vegetables)";
            // 
            // nud29
            // 
            this.nud29.BackColor = System.Drawing.Color.White;
            this.nud29.ForeColor = System.Drawing.Color.Maroon;
            this.nud29.Location = new System.Drawing.Point(19, 343);
            this.nud29.Margin = new System.Windows.Forms.Padding(4);
            this.nud29.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud29.Name = "nud29";
            this.nud29.Size = new System.Drawing.Size(56, 27);
            this.nud29.TabIndex = 97;
            this.nud29.ValueChanged += new System.EventHandler(this.nud29_ValueChanged);
            // 
            // nud21
            // 
            this.nud21.BackColor = System.Drawing.Color.White;
            this.nud21.ForeColor = System.Drawing.Color.Maroon;
            this.nud21.Location = new System.Drawing.Point(19, 38);
            this.nud21.Margin = new System.Windows.Forms.Padding(4);
            this.nud21.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud21.Name = "nud21";
            this.nud21.Size = new System.Drawing.Size(56, 27);
            this.nud21.TabIndex = 81;
            this.nud21.ValueChanged += new System.EventHandler(this.nud21_ValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(83, 162);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(353, 20);
            this.label30.TabIndex = 87;
            this.label30.Text = "24 Seeds of Change (Hispaniola Rice & Beans)";
            // 
            // nud28
            // 
            this.nud28.BackColor = System.Drawing.Color.White;
            this.nud28.ForeColor = System.Drawing.Color.Maroon;
            this.nud28.Location = new System.Drawing.Point(19, 305);
            this.nud28.Margin = new System.Windows.Forms.Padding(4);
            this.nud28.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud28.Name = "nud28";
            this.nud28.Size = new System.Drawing.Size(56, 27);
            this.nud28.TabIndex = 95;
            this.nud28.ValueChanged += new System.EventHandler(this.nud28_ValueChanged);
            // 
            // nud22
            // 
            this.nud22.BackColor = System.Drawing.Color.White;
            this.nud22.ForeColor = System.Drawing.Color.Maroon;
            this.nud22.Location = new System.Drawing.Point(19, 76);
            this.nud22.Margin = new System.Windows.Forms.Padding(4);
            this.nud22.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud22.Name = "nud22";
            this.nud22.Size = new System.Drawing.Size(56, 27);
            this.nud22.TabIndex = 84;
            this.nud22.ValueChanged += new System.EventHandler(this.nud22_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(83, 277);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(356, 20);
            this.label24.TabIndex = 94;
            this.label24.Text = "27 Edward & Sons (Reduced Sodium Miso Cup)";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(83, 86);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(315, 20);
            this.label29.TabIndex = 83;
            this.label29.Text = "22 Annie Chun’s (Pad Thai Noodle Bowl)";
            // 
            // nud27
            // 
            this.nud27.BackColor = System.Drawing.Color.White;
            this.nud27.ForeColor = System.Drawing.Color.Maroon;
            this.nud27.Location = new System.Drawing.Point(19, 267);
            this.nud27.Margin = new System.Windows.Forms.Padding(4);
            this.nud27.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud27.Name = "nud27";
            this.nud27.Size = new System.Drawing.Size(56, 27);
            this.nud27.TabIndex = 93;
            this.nud27.ValueChanged += new System.EventHandler(this.nud27_ValueChanged);
            // 
            // nud23
            // 
            this.nud23.BackColor = System.Drawing.Color.White;
            this.nud23.ForeColor = System.Drawing.Color.Maroon;
            this.nud23.Location = new System.Drawing.Point(19, 114);
            this.nud23.Margin = new System.Windows.Forms.Padding(4);
            this.nud23.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud23.Name = "nud23";
            this.nud23.Size = new System.Drawing.Size(56, 27);
            this.nud23.TabIndex = 85;
            this.nud23.ValueChanged += new System.EventHandler(this.nud23_ValueChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(83, 390);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(280, 20);
            this.label25.TabIndex = 98;
            this.label25.Text = "30 TapSoup (Pinoy Beef Tapa Soup)";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(83, 201);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(245, 20);
            this.label28.TabIndex = 90;
            this.label28.Text = "25 Tasty Bite (Channa Masala)";
            // 
            // nud26
            // 
            this.nud26.BackColor = System.Drawing.Color.White;
            this.nud26.ForeColor = System.Drawing.Color.Maroon;
            this.nud26.Location = new System.Drawing.Point(19, 229);
            this.nud26.Margin = new System.Windows.Forms.Padding(4);
            this.nud26.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud26.Name = "nud26";
            this.nud26.Size = new System.Drawing.Size(56, 27);
            this.nud26.TabIndex = 92;
            this.nud26.ValueChanged += new System.EventHandler(this.nud26_ValueChanged);
            // 
            // nud24
            // 
            this.nud24.BackColor = System.Drawing.Color.White;
            this.nud24.ForeColor = System.Drawing.Color.Maroon;
            this.nud24.Location = new System.Drawing.Point(19, 153);
            this.nud24.Margin = new System.Windows.Forms.Padding(4);
            this.nud24.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud24.Name = "nud24";
            this.nud24.Size = new System.Drawing.Size(56, 27);
            this.nud24.TabIndex = 88;
            this.nud24.ValueChanged += new System.EventHandler(this.nud24_ValueChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(83, 318);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(288, 20);
            this.label26.TabIndex = 96;
            this.label26.Text = "28 Spice Hunter (Spicy Thai Noodle)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(83, 241);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(369, 20);
            this.label27.TabIndex = 91;
            this.label27.Text = "26 Kitchens of India (Red Kidney Beans Curry)";
            // 
            // nud25
            // 
            this.nud25.BackColor = System.Drawing.Color.White;
            this.nud25.ForeColor = System.Drawing.Color.Maroon;
            this.nud25.Location = new System.Drawing.Point(19, 191);
            this.nud25.Margin = new System.Windows.Forms.Padding(4);
            this.nud25.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud25.Name = "nud25";
            this.nud25.Size = new System.Drawing.Size(56, 27);
            this.nud25.TabIndex = 89;
            this.nud25.ValueChanged += new System.EventHandler(this.nud25_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(79, 314);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 20);
            this.label9.TabIndex = 49;
            this.label9.Text = "08 Popchips (Barbeque)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(79, 278);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(259, 20);
            this.label10.TabIndex = 48;
            this.label10.Text = "07 Terrachips (Original Sea Salt)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(79, 241);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(254, 20);
            this.label11.TabIndex = 47;
            this.label11.Text = "06 EnviroKidz (Crispy Rice Bar)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(79, 201);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(237, 20);
            this.label5.TabIndex = 46;
            this.label5.Text = "05 Clif Bar (Blueberry Snack)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(79, 162);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(304, 20);
            this.label4.TabIndex = 45;
            this.label4.Text = "04 Kashi, TLC (Chewy Dark Chocolate)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(79, 126);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 20);
            this.label3.TabIndex = 44;
            this.label3.Text = "03 Reed\'s (Ginger Candy)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 86);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 20);
            this.label2.TabIndex = 43;
            this.label2.Text = "02 Yummy Earth (Lollipop)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 20);
            this.label1.TabIndex = 42;
            this.label1.Text = "01 Surf Sweets (Jelly Beans)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(79, 390);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(335, 20);
            this.label13.TabIndex = 60;
            this.label13.Text = "10 Primal Strips (Smoked Meatless Jerky)";
            // 
            // nud1
            // 
            this.nud1.BackColor = System.Drawing.Color.White;
            this.nud1.ForeColor = System.Drawing.Color.Maroon;
            this.nud1.Location = new System.Drawing.Point(15, 37);
            this.nud1.Margin = new System.Windows.Forms.Padding(4);
            this.nud1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud1.Name = "nud1";
            this.nud1.Size = new System.Drawing.Size(56, 27);
            this.nud1.TabIndex = 41;
            this.nud1.ValueChanged += new System.EventHandler(this.nud1_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(79, 354);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(313, 20);
            this.label12.TabIndex = 61;
            this.label12.Text = "09 Clif Bar, Luna (Nutz Over Chocolate)";
            // 
            // nud2
            // 
            this.nud2.ForeColor = System.Drawing.Color.Maroon;
            this.nud2.Location = new System.Drawing.Point(15, 76);
            this.nud2.Margin = new System.Windows.Forms.Padding(4);
            this.nud2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud2.Name = "nud2";
            this.nud2.Size = new System.Drawing.Size(56, 27);
            this.nud2.TabIndex = 62;
            this.nud2.ValueChanged += new System.EventHandler(this.nud2_ValueChanged);
            // 
            // nud3
            // 
            this.nud3.ForeColor = System.Drawing.Color.Maroon;
            this.nud3.Location = new System.Drawing.Point(15, 116);
            this.nud3.Margin = new System.Windows.Forms.Padding(4);
            this.nud3.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud3.Name = "nud3";
            this.nud3.Size = new System.Drawing.Size(56, 27);
            this.nud3.TabIndex = 63;
            this.nud3.ValueChanged += new System.EventHandler(this.nud3_ValueChanged);
            // 
            // nud4
            // 
            this.nud4.ForeColor = System.Drawing.Color.Maroon;
            this.nud4.Location = new System.Drawing.Point(15, 151);
            this.nud4.Margin = new System.Windows.Forms.Padding(4);
            this.nud4.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud4.Name = "nud4";
            this.nud4.Size = new System.Drawing.Size(56, 27);
            this.nud4.TabIndex = 64;
            this.nud4.ValueChanged += new System.EventHandler(this.nud4_ValueChanged);
            // 
            // nud5
            // 
            this.nud5.ForeColor = System.Drawing.Color.Maroon;
            this.nud5.Location = new System.Drawing.Point(15, 190);
            this.nud5.Margin = new System.Windows.Forms.Padding(4);
            this.nud5.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud5.Name = "nud5";
            this.nud5.Size = new System.Drawing.Size(56, 27);
            this.nud5.TabIndex = 65;
            this.nud5.ValueChanged += new System.EventHandler(this.nud5_ValueChanged);
            // 
            // nud6
            // 
            this.nud6.ForeColor = System.Drawing.Color.Maroon;
            this.nud6.Location = new System.Drawing.Point(15, 228);
            this.nud6.Margin = new System.Windows.Forms.Padding(4);
            this.nud6.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud6.Name = "nud6";
            this.nud6.Size = new System.Drawing.Size(56, 27);
            this.nud6.TabIndex = 66;
            this.nud6.ValueChanged += new System.EventHandler(this.nud6_ValueChanged);
            // 
            // nud7
            // 
            this.nud7.ForeColor = System.Drawing.Color.Maroon;
            this.nud7.Location = new System.Drawing.Point(15, 266);
            this.nud7.Margin = new System.Windows.Forms.Padding(4);
            this.nud7.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud7.Name = "nud7";
            this.nud7.Size = new System.Drawing.Size(56, 27);
            this.nud7.TabIndex = 67;
            this.nud7.ValueChanged += new System.EventHandler(this.nud7_ValueChanged);
            // 
            // nud8
            // 
            this.nud8.ForeColor = System.Drawing.Color.Maroon;
            this.nud8.Location = new System.Drawing.Point(15, 305);
            this.nud8.Margin = new System.Windows.Forms.Padding(4);
            this.nud8.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud8.Name = "nud8";
            this.nud8.Size = new System.Drawing.Size(56, 27);
            this.nud8.TabIndex = 68;
            this.nud8.ValueChanged += new System.EventHandler(this.nud8_ValueChanged);
            // 
            // nud9
            // 
            this.nud9.ForeColor = System.Drawing.Color.Maroon;
            this.nud9.Location = new System.Drawing.Point(15, 345);
            this.nud9.Margin = new System.Windows.Forms.Padding(4);
            this.nud9.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud9.Name = "nud9";
            this.nud9.Size = new System.Drawing.Size(56, 27);
            this.nud9.TabIndex = 69;
            this.nud9.ValueChanged += new System.EventHandler(this.nud9_ValueChanged);
            // 
            // nud10
            // 
            this.nud10.ForeColor = System.Drawing.Color.Maroon;
            this.nud10.Location = new System.Drawing.Point(15, 380);
            this.nud10.Margin = new System.Windows.Forms.Padding(4);
            this.nud10.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud10.Name = "nud10";
            this.nud10.Size = new System.Drawing.Size(56, 27);
            this.nud10.TabIndex = 70;
            this.nud10.ValueChanged += new System.EventHandler(this.nud10_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox1.Controls.Add(this.nud10);
            this.groupBox1.Controls.Add(this.nud9);
            this.groupBox1.Controls.Add(this.nud8);
            this.groupBox1.Controls.Add(this.nud7);
            this.groupBox1.Controls.Add(this.nud6);
            this.groupBox1.Controls.Add(this.nud5);
            this.groupBox1.Controls.Add(this.nud4);
            this.groupBox1.Controls.Add(this.nud3);
            this.groupBox1.Controls.Add(this.nud2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.nud1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Font = new System.Drawing.Font("Bell Gothic Std Black", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(441, 433);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hearty Treats @ 2.00 AED Each";
            // 
            // GroupBoxEnterCredit
            // 
            this.GroupBoxEnterCredit.Controls.Add(this.GroupBoxRunningCredit);
            this.GroupBoxEnterCredit.Controls.Add(this.btnNext);
            this.GroupBoxEnterCredit.Controls.Add(this.textboxBill);
            this.GroupBoxEnterCredit.Controls.Add(this.label32);
            this.GroupBoxEnterCredit.Controls.Add(this.label36);
            this.GroupBoxEnterCredit.Controls.Add(this.Label34);
            this.GroupBoxEnterCredit.Location = new System.Drawing.Point(485, 460);
            this.GroupBoxEnterCredit.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBoxEnterCredit.Name = "GroupBoxEnterCredit";
            this.GroupBoxEnterCredit.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBoxEnterCredit.Size = new System.Drawing.Size(956, 272);
            this.GroupBoxEnterCredit.TabIndex = 45;
            this.GroupBoxEnterCredit.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(118, 194);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(680, 49);
            this.label36.TabIndex = 6;
            this.label36.Text = "A maximum of 100 AED only. ❤";
            // 
            // Label34
            // 
            this.Label34.BackColor = System.Drawing.Color.Black;
            this.Label34.Font = new System.Drawing.Font("Bell Gothic Std Light", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label34.ForeColor = System.Drawing.Color.White;
            this.Label34.Location = new System.Drawing.Point(321, 84);
            this.Label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(176, 95);
            this.Label34.TabIndex = 5;
            this.Label34.Text = "AED";
            this.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.IndianRed;
            this.btnNext.Font = new System.Drawing.Font("Bell Gothic Std Light", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(505, 84);
            this.btnNext.Margin = new System.Windows.Forms.Padding(4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(391, 95);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = "&Next >";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // textboxBill
            // 
            this.textboxBill.BackColor = System.Drawing.SystemColors.InfoText;
            this.textboxBill.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textboxBill.Font = new System.Drawing.Font("Bell Gothic Std Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxBill.ForeColor = System.Drawing.Color.White;
            this.textboxBill.Location = new System.Drawing.Point(51, 84);
            this.textboxBill.Margin = new System.Windows.Forms.Padding(4);
            this.textboxBill.MaxLength = 1000;
            this.textboxBill.Name = "textboxBill";
            this.textboxBill.Size = new System.Drawing.Size(272, 96);
            this.textboxBill.TabIndex = 1;
            this.textboxBill.Text = "0";
            this.textboxBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textboxBill.TextChanged += new System.EventHandler(this.textboxBill_TextChanged);
            this.textboxBill.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textboxBill_KeyPress);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(12, 19);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(869, 49);
            this.label32.TabIndex = 0;
            this.label32.Text = "Please insert your bill on the cash slot! ❤";
            // 
            // pictureArrow
            // 
            this.pictureArrow.Image = ((System.Drawing.Image)(resources.GetObject("pictureArrow.Image")));
            this.pictureArrow.Location = new System.Drawing.Point(15, 454);
            this.pictureArrow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureArrow.Name = "pictureArrow";
            this.pictureArrow.Size = new System.Drawing.Size(425, 278);
            this.pictureArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureArrow.TabIndex = 47;
            this.pictureArrow.TabStop = false;
            // 
            // frmHearty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1469, 758);
            this.Controls.Add(this.pictureArrow);
            this.Controls.Add(this.GroupBoxEnterCredit);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtTotalPrice);
            this.Controls.Add(this.label8);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmHearty";
            this.Text = "Hearty Vending Machine";
            this.Load += new System.EventHandler(this.frmHearty_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud20)).EndInit();
            this.GroupBoxRunningCredit.ResumeLayout(false);
            this.GroupBoxRunningCredit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud10)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.GroupBoxEnterCredit.ResumeLayout(false);
            this.GroupBoxEnterCredit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nud20;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown nud18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown nud17;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nud15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown nud14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown nud13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown nud12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown nud11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown nud30;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown nud29;
        private System.Windows.Forms.NumericUpDown nud21;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown nud28;
        private System.Windows.Forms.NumericUpDown nud22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown nud27;
        private System.Windows.Forms.NumericUpDown nud23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown nud26;
        private System.Windows.Forms.NumericUpDown nud24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown nud25;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nud1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nud2;
        private System.Windows.Forms.NumericUpDown nud3;
        private System.Windows.Forms.NumericUpDown nud4;
        private System.Windows.Forms.NumericUpDown nud5;
        private System.Windows.Forms.NumericUpDown nud6;
        private System.Windows.Forms.NumericUpDown nud7;
        private System.Windows.Forms.NumericUpDown nud8;
        private System.Windows.Forms.NumericUpDown nud9;
        private System.Windows.Forms.NumericUpDown nud10;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.GroupBox GroupBoxEnterCredit;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.Button btnNext;
        internal System.Windows.Forms.TextBox textboxBill;
        internal System.Windows.Forms.Label label32;
        internal System.Windows.Forms.GroupBox GroupBoxRunningCredit;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Label LabelCredit;
        internal System.Windows.Forms.Button btnFinalNext;
        internal System.Windows.Forms.Label label35;
        internal System.Windows.Forms.Button btnCancel;
        internal System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureArrow;
    }
}

